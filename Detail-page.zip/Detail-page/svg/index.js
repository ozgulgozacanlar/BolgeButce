export { default as Home } from './Home';
export { default as Detail } from './Detail';
export { default as LoaderSVG } from './Loader';
export { default as ErrorSVG } from './Error';
export { default as GarantiLogo } from './GarantiLogo';
export { default as DownChevron } from './DownChevron';
export { default as LeftChevron } from './LeftChevron';
export { default as Menu } from './Menu';
