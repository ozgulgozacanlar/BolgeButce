import { PageMainButton, HighLowTable } from '@/components';

export default function Detail() {
  return (
    <div className="container mt-3">
      <div className="d-flex justify-content-end">
        <PageMainButton title="Metrik Detayı" />
      </div>
      <div className="row mt-3">
        <div className="col-12 col-xl-4 d-flex">
          <div className="card">
            <div className="card-title">Bölge Pusula Performansı</div>
            <div className="card-content">
              chart goes here
              <br />
              bar color: #2b85c9
            </div>
          </div>
        </div>
        <div className="col-12 col-xl-4 d-flex">
          <div className="card">
            <div className="card-title">Bölge Toplamı</div>
            <div className="card-content">
              <div className="d-flex justify-content-around column-gap-5">
                <HighLowTable />
                <HighLowTable />
              </div>
            </div>
          </div>
        </div>
        <div className="col-12 col-xl-4 d-flex">
          <div className="card">
            <div className="card-title">Bireysel</div>
            <div className="card-content">
              <div className="d-flex justify-content-around column-gap-5">
                <HighLowTable />
                <HighLowTable />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="row mt-4">
        <div className="col-12 col-xl-4 d-flex">
          <div className="card">
            <div className="card-title">Şube Pusula Performansı</div>
            <div className="card-content">
              chart goes here
              <br />
              bar color: #a1c789
            </div>
          </div>
        </div>
        <div className="col-12 col-xl-4 d-flex">
          <div className="card">
            <div className="card-title">KOBİ</div>
            <div className="card-content">
              <div className="d-flex justify-content-around column-gap-5">
                <HighLowTable />
                <HighLowTable />
              </div>
            </div>
          </div>
        </div>
        <div className="col-12 col-xl-4 d-flex">
          <div className="card">
            <div className="card-title">Ticari</div>
            <div className="card-content">
              <div className="d-flex justify-content-around column-gap-5">
                <HighLowTable />
                <HighLowTable />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
