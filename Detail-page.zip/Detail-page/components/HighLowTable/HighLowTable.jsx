import './HighLowTable.css';

export default function HighLowTable() {
  return (
    <table className='high-low-table'>
      <thead>
        <tr>
          <th colSpan={2}>En Yüksek 5</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th><div>Ataşehir</div></th>
          <td>%104</td>
        </tr>
        <tr>
          <th><div>Ataşehir</div></th>
          <td>%104</td>
        </tr>
        <tr>
          <th><div>Ataşehir</div></th>
          <td>%104</td>
        </tr>
        <tr>
          <th><div>Ataşehir Halkcad</div></th>
          <td>%104</td>
        </tr>
        <tr>
          <th><div>Ataşehir</div></th>
          <td>%104</td>
        </tr>
      </tbody>
    </table>
  );
}
