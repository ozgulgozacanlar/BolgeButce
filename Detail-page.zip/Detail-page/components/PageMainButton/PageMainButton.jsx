import './PageMainButton.css';
import  { Menu }  from '@/assets/svg';

export default function PageMainButton({title}) {
  return (
    <div className="page-main-button">
       <Menu />
      {title}
    </div>
  );
}
